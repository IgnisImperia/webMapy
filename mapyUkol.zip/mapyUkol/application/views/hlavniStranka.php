<br>       
<div class="container">
    <center><img src="https://images.creativemarket.com/0.1.0/ps/573647/1160/772/m1/fpnw/wm0/back-to-school-.jpg?1437430265&s=39c8b6145cad0d1c9da70b2fc7b913e8"></center>      
            <br>
            <br>
            <br>
            <br>
          
<footer class="page-footer font-small blue">
  <div class="footer-copyright text-center py-3">
    <a href=""> Petr Hluštík</a>
  </div>
</footer>
        </div>

